from setuptools import setup


setup(
name="firstmodule",
version="0.0.1",
description="descripton of fristmodule",
author="soorya srihari", 
long_description="sldkjflsjdfljsl;dfj;sldkjfsl;dkfj ;sldkjf lskdjfls;dkjf sdlkfj s;dlkfj ldkfj dslkfjsldkfj sldkf jdl ",
author_email="randi@gmail.com",
scripts=["firstmodule.py"],
py_modules=["firstmodule"]


)